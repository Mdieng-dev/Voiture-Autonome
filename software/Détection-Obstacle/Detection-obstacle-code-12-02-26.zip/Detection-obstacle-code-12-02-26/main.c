#include "stm32f4xx.h"                  // Device header
#include "Driver_I2C.h"                 // CMSIS Driver:I2C
#include "RTE_Components.h"             // Component selection
#include "RTE_Device.h"                 // Device:STM32Cube Framework:Classic
#include "stm32f4xx_hal.h"              // Device:STM32Cube HAL:Common
#include "stm32f4xx_hal_conf.h"         // Device:STM32Cube Framework:Classic


extern ARM_DRIVER_I2C Driver_I2C1;
static ARM_DRIVER_I2C *I2Cdrv = &Driver_I2C1;

void I2C_Initialize_Hardware(void) {
    
    // 1. Initialisation du Driver (liaison avec les fonctions de rappel si n�cessaire)
    I2Cdrv->Initialize(NULL);
    
    // 2. Mise sous tension du p�riph�rique
    I2Cdrv->PowerControl(ARM_POWER_FULL);
    
    // 3. Configuration de la vitesse (Standard = 100 kHz)
    I2Cdrv->Control(ARM_I2C_BUS_SPEED, ARM_I2C_BUS_SPEED_STANDARD);
    
    // 4. Lib�ration du bus (envoie 9 pulses pour d�bloquer les esclaves si besoin)
    I2Cdrv->Control(ARM_I2C_BUS_CLEAR, 0);
}

uint8_t ReadSensorValue( uint8_t addr, uint8_t reg) {
    uint8_t val,tab[10];
		
		tab[0]=reg;

    // 1. Envoyer l'adresse du registre (Master Transmit)
    // Le param�tre "true" � la fin maintient le bus occup� (RESTART condition)
    I2Cdrv->MasterTransmit(addr, tab, 1, true);
    
    // Attendre que le transfert soit termin�
    while (I2Cdrv->GetStatus().busy);
    if (I2Cdrv->GetDataCount() != 1) return 0xFF; // Erreur d'envoi

    // 2. Lire la valeur du registre (Master Receive)
    // Le param�tre "false" termine la transaction par un signal STOP
    I2Cdrv->MasterReceive(addr, &val, 1, false);
    
    // Attendre la fin de la r�ception
    while (I2Cdrv->GetStatus().busy);
    
    return val;
}

int main(void) {

				
		// Initialisation de l'horloge syst�me (typiquement 168 MHz sur F407)
    SystemCoreClockUpdate();

    // Configuration I2C
    I2C_Initialize_Hardware();
		
		
    while (1) {
				ReadSensorValue(0xE0>>1,0x51);
        ReadSensorValue(0xE2>>1,0x51);
			
    }
}